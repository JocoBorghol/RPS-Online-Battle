// --- Lista över dina avatars (Exakt som dina filer heter) ---
const avatarList = [
    'Hero.png',
    'EnemySkeletton.png',
    'DemonTroll.png',
    'Lizard.png',
    'Wolf.png'
];

// Spelvariabler
let playerScore = 0;
let enemyScore = 0;
let currentRound = 1;
const maxRounds = 5; 
let isAnimating = false;
let matchCount = 0;

// DOM Element
const playerHandElem = document.getElementById('player-hand');
const enemyHandElem = document.getElementById('enemy-hand');
const playerChoiceText = document.getElementById('player-choice-text');
const enemyChoiceText = document.getElementById('enemy-choice-text');
const playerScoreElem = document.getElementById('player-score');
const enemyScoreElem = document.getElementById('enemy-score');
const roundDisplay = document.getElementById('round-display');
const gameMessage = document.getElementById('game-message');
const roundList = document.getElementById('round-list');
const matchList = document.getElementById('match-list');
const controlsDiv = document.getElementById('controls');
const gameOverPanel = document.getElementById('game-over-panel');
const playerImg = document.getElementById('player-img');

// Hämta namnelementen
const playerNameElem = document.querySelector('.player-name');
const enemyNameElem = document.querySelector('.enemy-name');
const enemyImg = document.querySelector('.enemy-zone .avatar');


// Symboler
const hands = {
    sten: '✊🏽',
    sax: '✌🏽',
    pase: '✋🏽',
    rocknroll_player: '🤘🏽',
    rocknroll_enemy: '🤘💀'
};

// --- HJÄLPFUNKTION: Skapa namn från filnamn ---
function formatName(filename) {
    if (!filename) return "Unknown";
    return filename.split('.')[0];
}

// --- INITIALISERING (Körs när sidan laddas) ---
function initGame() {
    const currentPlayerSrc = playerImg.getAttribute('src').split('/').pop();
    playerNameElem.innerText = formatName(currentPlayerSrc);

    const currentEnemySrc = enemyImg.getAttribute('src').split('/').pop();
    enemyNameElem.innerText = formatName(currentEnemySrc);
}

// --- FUNKTIONER FÖR AVATAR-VAL ---
function openAvatarModal() {
    const modal = document.getElementById('avatar-modal');
    const grid = document.getElementById('avatar-grid');
    grid.innerHTML = ''; 

    avatarList.forEach(filename => {
        const img = document.createElement('img');
        img.src = `images/${filename}`;
        img.alt = filename;
        img.className = 'avatar-thumbnail';
        img.onclick = function() {
            changeAvatar(filename);
        };
        grid.appendChild(img);
    });

    modal.classList.remove('hidden');
}

function closeAvatarModal() {
    document.getElementById('avatar-modal').classList.add('hidden');
}

function changeAvatar(filename) {
    playerImg.src = `images/${filename}`;
    playerNameElem.innerText = formatName(filename);
    closeAvatarModal();
}

window.onclick = function(event) {
    const modal = document.getElementById('avatar-modal');
    if (event.target == modal) {
        closeAvatarModal();
    }
}

// --- SPEL-LOGIK ---

function restartGame() {
    playerScore = 0;
    enemyScore = 0;
    currentRound = 1;
    roundList.innerHTML = "";
    updateUI();
    resetHands();
    gameMessage.innerText = "NY MATCH!";
    gameMessage.style.color = "#fff";
    controlsDiv.classList.remove('hidden');
    gameOverPanel.classList.add('hidden');
    enableButtons();
}

function resetHands() {
    playerHandElem.innerText = hands.rocknroll_player;
    enemyHandElem.innerText = hands.rocknroll_enemy;
    playerChoiceText.innerText = "REDO";
    enemyChoiceText.innerText = "REDO";
    playerChoiceText.style.opacity = "0.5";
    enemyChoiceText.style.opacity = "0.5";
    playerHandElem.classList.remove('shake', 'pop');
    enemyHandElem.classList.remove('shake', 'pop');
}

function updateUI() {
    playerScoreElem.innerText = playerScore;
    enemyScoreElem.innerText = enemyScore;
    roundDisplay.innerText = `Runda ${currentRound} / ${maxRounds}`;
}

function playGame(playerChoice) {
    if (isAnimating) return;
    isAnimating = true;
    disableButtons();

    playerHandElem.innerText = hands.rocknroll_player;
    enemyHandElem.innerText = hands.rocknroll_enemy;
    playerChoiceText.innerText = "";
    enemyChoiceText.innerText = "";
    gameMessage.innerText = "KÄMPAR...";
    gameMessage.style.color = "#ccc";

    playerHandElem.classList.remove('pop');
    enemyHandElem.classList.remove('pop');
    playerHandElem.classList.add('shake');
    enemyHandElem.classList.add('shake');

    const choices = ['sten', 'sax', 'pase'];
    const enemyChoice = choices[Math.floor(Math.random() * choices.length)];

    setTimeout(() => {
        playerHandElem.classList.remove('shake');
        enemyHandElem.classList.remove('shake');
        playerHandElem.classList.add('pop');
        enemyHandElem.classList.add('pop');

        playerHandElem.innerText = hands[playerChoice];
        enemyHandElem.innerText = hands[enemyChoice];
        
        playerChoiceText.innerText = playerChoice.toUpperCase();
        enemyChoiceText.innerText = mapChoiceToSwedish(enemyChoice);
        playerChoiceText.style.opacity = "1";
        enemyChoiceText.style.opacity = "1";

        const result = determineWinner(playerChoice, enemyChoice);
        handleResult(result);
        isAnimating = false;

        if (currentRound > maxRounds) {
            endMatch();
        } else {
            enableButtons();
        }
    }, 600);
}

function mapChoiceToSwedish(choice) {
    if(choice === 'pase') return 'PÅSE';
    return choice.toUpperCase();
}

function determineWinner(p, e) {
    if (p === e) return 'draw';
    if ((p === 'sten' && e === 'sax') || (p === 'sax' && e === 'pase') || (p === 'pase' && e === 'sten')) {
        return 'win';
    } else {
        return 'lose';
    }
}

function handleResult(result) {
    let msg = "", logClass = "", logText = "";
    const pName = playerNameElem.innerText;
    const eName = enemyNameElem.innerText;

    if (result === 'win') {
        playerScore += 10; 
        msg = `${pName} VANN!`;
        gameMessage.style.color = "#2ecc71"; logClass = "text-win"; logText = "VINST";
    } else if (result === 'lose') {
        enemyScore += 10; 
        msg = `${eName} VANN!`;
        gameMessage.style.color = "#e74c3c"; logClass = "text-lose"; logText = "FÖRLUST";
    } else {
        msg = "OAVGJORT!"; gameMessage.style.color = "#f1c40f"; logClass = "text-draw"; logText = "OAVGJORT";
    }
    gameMessage.innerText = msg;
    addRoundHistory(currentRound, logText, logClass);
    currentRound++;
    updateUI();
}

function addRoundHistory(round, text, cssClass) {
    const li = document.createElement('li');
    li.className = "round-item";
    li.innerHTML = `<span>Runda ${round}</span> <span class="${cssClass}">${text}</span>`;
    roundList.prepend(li);
}

function endMatch() {
    let finalMsg = "", matchResult = "";
    matchCount++;
    if (playerScore > enemyScore) {
        finalMsg = "MATCHVINST! 🏆"; gameMessage.style.color = "#2ecc71"; matchResult = `<span class="text-win">VINST (${playerScore}p)</span>`;
    } else if (enemyScore > playerScore) {
        finalMsg = "MATCHFÖRLUST 💀"; gameMessage.style.color = "#e74c3c"; matchResult = `<span class="text-lose">FÖRLUST (${enemyScore}p)</span>`;
    } else {
        finalMsg = "MATCH OAVGJORD"; gameMessage.style.color = "#f1c40f"; matchResult = `<span class="text-draw">LIKA (${playerScore}p)</span>`;
    }
    roundDisplay.innerText = "GAME OVER";
    gameMessage.innerText = finalMsg;
    const li = document.createElement('li');
    li.className = "match-item";
    li.innerHTML = `Match ${matchCount}: ${matchResult}`;
    matchList.prepend(li);
    controlsDiv.classList.add('hidden');
    gameOverPanel.classList.remove('hidden');
}

function disableButtons() {
    document.querySelectorAll('.game-btn').forEach(btn => { btn.disabled = true; btn.style.opacity = "0.5"; btn.style.cursor = "not-allowed"; });
}
function enableButtons() {
    document.querySelectorAll('.game-btn').forEach(btn => { btn.disabled = false; btn.style.opacity = "1"; btn.style.cursor = "pointer"; });
}

updateUI();
initGame();